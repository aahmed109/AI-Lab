import random
from copy import deepcopy
from ctypes import windll

import pygame

timeBeginPeriod = windll.winmm.timeBeginPeriod
timeBeginPeriod(1)
pygame.init()

global moves
moves = 0
limitSix = 10
limitTen = 17
limitFourteen = 25

sixState = 0
tenState = 0
fourteenState = 0

black = (0, 0, 0)
red = (204, 0, 0)
light_red = (255, 0, 0)
green = (0, 204, 0)
light_green = (0, 255, 0)
blue = (0, 0, 204)
light_blue = (0, 0, 255)
violet = (238, 130, 238)
yellow = (204, 204, 0)
light_yellow = (255, 255, 0)
pest = (0, 255, 255)
skin = (255, 204, 153)
white = (255, 255, 255)

colors = [red, green, blue, yellow, violet, pest]

connected = [(0,0),[0]*15]

gameArray = [[0]*14 for _ in range(14)]

sixGameArray1 = [[red, red, red, yellow, violet, pest],
                 [yellow, pest, pest, red, pest, red],
                 [red, red, pest, yellow, violet, skin],
                 [violet, violet, red, violet, violet, green],
                 [violet, skin, skin, violet, yellow, green],
                 [red, pest, yellow, violet, skin, yellow]]

sixGameArray2 = [[green, pest, green, green, red, red],
                 [green, red, red, green, red, yellow],
                 [yellow, pest, violet, green, yellow, skin],
                 [pest, red, red, pest, red, yellow],
                 [red, yellow, skin, pest, violet, red],
                 [skin, yellow, green, violet, skin, red]]

sixGameArray3 = [[colors[0], colors[1], colors[2], colors[3], colors[1], colors[2]],
                 [colors[2], colors[2], colors[3], colors[4], colors[1], colors[0]],
                 [colors[3], colors[2], colors[2], colors[0], colors[1], colors[2]],
                 [colors[4], colors[3], colors[2], colors[5], colors[1], colors[0]],
                 [colors[2], colors[1], colors[3], colors[2], colors[3], colors[2]],
                 [colors[1], colors[2], colors[3], colors[0], colors[4], colors[5]]]

tenGameArray1 = [[pest, skin, violet, violet, red, pest, violet, violet, green, yellow],
                 [pest, green, red, skin, red, red, pest, skin, violet, red],
                 [pest, green, red, red, red, violet, pest, violet, yellow, yellow],
                 [skin, violet, green, skin, red, violet, yellow, violet, red, red],
                 [pest, skin, green, yellow, pest, pest, skin, skin, red, pest],
                 [yellow, skin, green, pest, red, pest, yellow, green, red, pest],
                 [red, skin, red, violet, skin, violet, pest, pest , violet, yellow],
                 [pest, violet, pest, pest, pest, green, red, red, pest, violet],
                 [green, yellow, pest, pest, red, skin, green, yellow, pest, yellow],
                 [pest, violet, violet, yellow, pest, green, yellow, skin, green, pest]]

tenGameArray2 = [[skin, red, yellow, violet, pest, yellow, skin, red, skin, yellow],
                 [pest, green, red, violet, pest, yellow, skin, red, pest, yellow],
                 [red, red, yellow, yellow, skin, violet, pest, yellow, yellow, red],
                 [pest, pest, green, red, red, skin, yellow, skin, green, green],
                 [yellow, yellow, violet, red, yellow, green, pest, red, violet, pest],
                 [red, pest, yellow, violet, yellow, green, red, green, yellow, red],
                 [green, pest, skin, yellow, red, yellow, green, pest, skin, green],
                 [yellow, red, violet, red, red, pest, skin, red, yellow, skin],
                 [violet, pest, skin, violet, violet, violet, violet, yellow, yellow, red],
                 [skin, red, pest, red, pest, violet, violet, yellow, pest, pest]]

fourteenGameArray1 = [[red, green, violet, pest, pest, green, red, skin, green, skin, violet, skin, violet, green],
                      [yellow, red, red, pest, violet, yellow, violet, red, violet, green, violet, green, yellow, violet],
                      [pest, skin, red, violet, green, red, red, red, violet, green, skin, red, violet, pest],
                      [violet, violet, green, red, green, yellow, pest, red, violet, red, red, pest, red, skin],
                      [violet, pest, skin, pest, violet, violet, yellow, red, skin, pest, green, red, violet, pest],
                      [red, violet, yellow, skin, green, violet, skin, green, red, violet, pest, yellow, pest, skin],
                      [green, violet, pest, violet, green, green, green, pest, green, yellow, green, red, pest, violet],
                      [yellow, skin, violet, pest, violet, yellow, red, red, pest, red, yellow, violet, violet, green],
                      [pest, pest, violet, pest, green, yellow, violet, red, violet, red, pest, yellow, red, skin],
                      [violet, skin, skin, green, pest, green, red, pest, skin, skin, skin, violet, violet, yellow],
                      [yellow, yellow, skin, yellow, violet, violet, green, green, red, skin, violet, skin, skin, green],
                      [green, yellow, red, violet, violet, red, green, green, green, skin, violet, green, pest, skin],
                      [violet, pest, yellow, yellow, skin, pest, green, yellow, violet, skin, violet, pest, skin, yellow],
                      [pest, pest, yellow, green, pest, pest, green, green, pest, red, yellow, pest, red, violet]]

fourteenGameArray2 = [[]]

gameDisplay = pygame.display.set_mode((600, 600))

pygame.display.set_caption('Flood-it')

smallFont = pygame.font.SysFont("comicsansms", 25)
medFont = pygame.font.SysFont("comicsansms", 50)
largeFont = pygame.font.SysFont("comicsansms", 80)


def message_in_button(msg, color, buttonX, buttonY, buttonWidth, buttonHeight, size="small"):
    textSurf, textRect = text_objects(msg, color, size)
    textRect.center = ((buttonX + (buttonWidth / 2)), (buttonY + (buttonHeight / 2)))
    gameDisplay.blit(textSurf, textRect)


def button(text, buttonX, buttonY, buttonWidth, buttonHeight, inactive_color, active_color, action = None):
    global mode
    cur = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    if buttonX + buttonWidth > cur[0] > buttonX and buttonY + buttonHeight > cur[1] > buttonY:
        pygame.draw.rect(gameDisplay, active_color, (buttonX, buttonY, buttonWidth, buttonHeight))

        if click[0] == 1 and action is not None:
            if action == "Exit":
                pygame.quit()
                quit()
            elif action == "6x6":
                mode = 6
                initDraw(mode)
            elif action == "10x10":
                mode = 10
                initDraw(mode)
            elif action == "14x14":
                mode = 14
                initDraw(mode)
            gameLoop(mode)
    else:
        pygame.draw.rect(gameDisplay, inactive_color, (buttonX, buttonY, buttonWidth, buttonHeight))

    message_in_button(text, black, buttonX, buttonY, buttonWidth, buttonHeight)


def game_intro():
    intro = True
    while intro:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        gameDisplay.fill(white)
        message_in_screen('Flood-it Game', blue, -200, "large")

        button("6x6 Board", 225, 250, 150, 50, yellow, light_yellow, action = "6x6")
        button("10x10 Board", 225, 330, 150, 50, green, light_green, action = "10x10")
        button("14x14 Board", 225, 410, 150, 50, blue, light_blue, action = "14x14")
        button("Exit", 225, 490, 150, 50, red, light_red, action = "Exit")
        pygame.display.update()


def text_objects(text, color, size):
    global textSurface
    if size == "small":
        textSurface = smallFont.render(text, True, color)
    elif size == "medium":
        textSurface = medFont.render(text, True, color)
    if size == "large":
        textSurface = largeFont.render(text, True, color)

    return textSurface, textSurface.get_rect()


def message_in_screen(msg, color, y_displace=0, size="small"):
    textSurf, textRect = text_objects(msg, color, size)

    textRect.center = 300, 300 + y_displace
    gameDisplay.blit(textSurf, textRect)


def gameDraw(n):
    for i in range(0, n):
        for j in range(0, n):
            pygame.draw.rect(gameDisplay, gameArray[i][j], [j * 30, i * 30, 30, 30])


def initDraw(n):
    moves = 0
    for i in range(0, n):
        for j in range(0, n):
            theColor = random.choice(colors)
            pygame.draw.rect(gameDisplay, theColor, [j * 30, i * 30, 30, 30])
            gameArray[i][j] = theColor


def checkConnected(m, nconnected, tgameArray):  # put all controlled grids in connected array
    for a in range (1,len(nconnected)):
        if nconnected[a][0] < 1 and nconnected[a][1] < 1:   # (0,0)
            if gameArray[0][1] == nconnected[0] and (0, 1) not in nconnected:
                nconnected.append((0, 1))
            if gameArray[1][0] == nconnected[0] and (1, 0) not in nconnected:
                nconnected.append((1, 0))

        elif nconnected[a][0] < 1 and nconnected[a][1] >= 1:    # row 1
            if nconnected[a][1]+1 < m and tgameArray[0][nconnected[a][1]+1] == nconnected[0] and (0, nconnected[a][1]+1) not in nconnected:
                nconnected.append((0,nconnected[a][1]+1))
            if tgameArray[1][nconnected[a][1]] == nconnected[0] and (1, nconnected[a][1]) not in nconnected:
                nconnected.append((1,nconnected[a][1]))
            if nconnected[a][1]-1 >= 0 and tgameArray[0][nconnected[a][1]-1] == nconnected[0] and (0, nconnected[a][1]-1) not in nconnected:
                nconnected.append((0,nconnected[a][1]-1))

        elif nconnected[a][1]<1 and nconnected[a][0]>=1:    #   column 1
            if nconnected[a][0]+1 < m and tgameArray[nconnected[a][0]+1][0] == nconnected[0] and (nconnected[a][0]+1,0) not in nconnected:
                nconnected.append((nconnected[a][0]+1,0))
            if tgameArray[nconnected[a][0]][1] == nconnected[0] and (nconnected[a][0], 1) not in nconnected:
                nconnected.append((nconnected[a][0],1))
            if nconnected[a][0]-1 >= 0 and tgameArray[nconnected[a][0]-1][0] == nconnected[0] and (nconnected[a][0]-1,0) not in nconnected:
                nconnected.append((nconnected[a][0]-1,0))

        else:
            if nconnected[a][1]-1 >= 0 and tgameArray[nconnected[a][0]][nconnected[a][1]-1] == nconnected[0] and (nconnected[a][0], nconnected[a][1]-1) not in nconnected:
                nconnected.append((nconnected[a][0],nconnected[a][1]-1))
            if nconnected[a][1]+1 < m and tgameArray[nconnected[a][0]][nconnected[a][1]+1] == nconnected[0] and (nconnected[a][0],nconnected[a][1]+1) not in nconnected:
                nconnected.append((nconnected[a][0],nconnected[a][1]+1))
            if nconnected[a][0]-1 >= 0 and tgameArray[nconnected[a][0]-1][nconnected[a][1]] == nconnected[0] and (nconnected[a][0]-1,nconnected[a][1]) not in nconnected:
                nconnected.append((nconnected[a][0]-1,nconnected[a][1]))
            if nconnected[a][0]+1 < m and tgameArray[nconnected[a][0]+1][nconnected[a][1]] == nconnected[0] and (nconnected[a][0]+1,nconnected[a][1]) not in nconnected:
                nconnected.append((nconnected[a][0]+1,nconnected[a][1]))


def addConnected(m, x, y):  # make all under control grids same colored
    global moves
    if x <= m-1 and x >= 0 and y <= m-1 and y >= 0 and (x, y) not in connected and gameArray[x][y] != connected[0]:
        moves += 1

        connected[0] = gameArray[x][y]
        gameArray[0][0] = gameArray[x][y]
        for s in range (2, len(connected)):
            gameArray[connected[s][0]][connected[s][1]] = gameArray[0][0]


def adjacentColors(m, nconnected, tgameArray):  # find all grids adjacent to controlled chunk
    adjacentcolor = []
    for a in range(1, len(nconnected)):
        if nconnected[a][0] < 1 and nconnected[a][1] < 1:   # (0,0)
            if tgameArray[0][1] != nconnected[0] and [tgameArray[0][1], (0,1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[0][1], (0, 1)])
            if tgameArray[1][0] != nconnected[0] and [tgameArray[1][0], (1, 0)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[1][0], (1, 0)])

        elif nconnected[a][0] < 1 and nconnected[a][1] >= 1:    # row 1
            if nconnected[a][1] + 1 < m and tgameArray[0][nconnected[a][1] + 1] != nconnected[0] and [tgameArray[0][nconnected[a][1] + 1], (0, nconnected[a][1]+1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[0][nconnected[a][1] + 1], (0, nconnected[a][1]+1)])
            if tgameArray[1][nconnected[a][1]] != nconnected[0] and [tgameArray[1][nconnected[a][1]], (1,nconnected[a][1])] not in adjacentcolor:
                adjacentcolor.append([tgameArray[1][nconnected[a][1]], (1,nconnected[a][1])])
            if nconnected[a][1] - 1 >= 0 and tgameArray[0][nconnected[a][1] - 1] != nconnected[0] and [tgameArray[0][nconnected[a][1] - 1], (0, nconnected[a][1]-1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[0][nconnected[a][1] - 1], (0, nconnected[a][1]-1)])

        elif nconnected[a][1]<1 and nconnected[a][0]>=1:    # column 1
            if nconnected[a][0] + 1 < m and tgameArray[nconnected[a][0] + 1][0] != nconnected[0] and [tgameArray[nconnected[a][0] + 1][0], (nconnected[a][0]+1,0)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0] + 1][0], (nconnected[a][0]+1,0)])
            if tgameArray[nconnected[a][0]][1] != nconnected[0] and [tgameArray[nconnected[a][0]][1], (nconnected[a][0],1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0]][1], (nconnected[a][0],1)])
            if nconnected[a][0] - 1 >= 0 and tgameArray[nconnected[a][0] - 1][0] != nconnected[0] and [tgameArray[nconnected[a][0] - 1][0], (nconnected[a][0]-1,0)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0] - 1][0], (nconnected[a][0]-1,0)])

        else:
            if nconnected[a][1] - 1 >= 0 and tgameArray[nconnected[a][0]][nconnected[a][1] - 1] != nconnected[0] and [tgameArray[nconnected[a][0]][nconnected[a][1] - 1], (nconnected[a][0], nconnected[a][1] - 1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0]][nconnected[a][1] - 1], (nconnected[a][0], nconnected[a][1] - 1)])
            if nconnected[a][1] + 1 < m and tgameArray[nconnected[a][0]][nconnected[a][1] + 1] != nconnected[0] and [tgameArray[nconnected[a][0]][nconnected[a][1] + 1], (nconnected[a][0], nconnected[a][1] + 1)] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0]][nconnected[a][1] + 1], (nconnected[a][0], nconnected[a][1] + 1)])
            if nconnected[a][0] - 1 >= 0 and tgameArray[nconnected[a][0] - 1][nconnected[a][1]] != nconnected[0] and [tgameArray[nconnected[a][0] - 1][nconnected[a][1]], (nconnected[a][0] - 1, nconnected[a][1])] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0] - 1][nconnected[a][1]], (nconnected[a][0] - 1, nconnected[a][1])])
            if nconnected[a][0] + 1 < m and tgameArray[nconnected[a][0] + 1][nconnected[a][1]] != nconnected[0] and [tgameArray[nconnected[a][0] + 1][nconnected[a][1]], (nconnected[a][0] + 1, nconnected[a][1])] not in adjacentcolor:
                adjacentcolor.append([tgameArray[nconnected[a][0] + 1][nconnected[a][1]], (nconnected[a][0] + 1, nconnected[a][1])])

    return adjacentcolor


def getBenefit(m, color, nconnected, tgameArray):   # find out chunk size of selecting a specific color
    newconnect = nconnected[:]

    tempGameArray = deepcopy(tgameArray)

    if color[1][0] < m and color[1][0] >= 0 and color[1][1] < m and color[1][1] >= 0 and (color[1][0], color[1][1]) not in newconnect and tempGameArray[color[1][0]][color[1][1]] != newconnect[0]:
        newconnect[0] = tempGameArray[color[1][0]][color[1][1]]

        tempGameArray[0][0] = tempGameArray[color[1][0]][color[1][1]]
        for s in range (2, len(newconnect)):
            tempGameArray[newconnect[s][0]][newconnect[s][1]] = tempGameArray[0][0]

        size = len(newconnect)-1

        while len(newconnect)>size:
            size = len(newconnect)
            checkConnected(m, newconnect, tempGameArray)

        return [color, len(newconnect)]


def countFriend(pos, friends, tgameArray):  # get total
    theColor = pos[0]
    position = pos[1]

    if position[0] < 1 and position[1] < 1:
        pass

    if position[0] < 1 and position[1] > 0:
        # left
        if position[1] - 1 >= 0 and tgameArray[position[0]][position[1]-1] == theColor and (position[0], position[1]-1) not in friends:
            friends.append((position[0], position[1]-1))
        # right
        if position[1] + 1 < mode and tgameArray[position[0]][position[1] + 1] == theColor and (position[0], position[1] + 1) not in friends:
            friends.append((position[0], position[1]+1))
        # down
        if tgameArray[1][position[1]] ==  theColor and (1, position[1]) not in friends:
            friends.append((1, position[1]))

    if position[0] > 0 and position[1] < 1:
        # up
        if position[0] - 1 >= 0 and tgameArray[position[0]][position[1]] == theColor and (position[0]-1, position[1]) not in friends:
            friends.append((position[0]-1, position[1]))
        # down
        if position[0] + 1 < mode and tgameArray[position[0]+1][position[1]] ==  theColor and (position[0]+1, position[1]) not in friends:
            friends.append((position[0]+1, position[1]))
        #right
        if tgameArray[position[0]][1] == theColor and (position[0], 1) not in friends:
            friends.append((position[0], 1))

    else:
        # right
        if position[1]+1 < mode and tgameArray[position[0]][position[1]+1] ==  theColor and (position[0], position[1]+1) not in friends:
            friends.append((position[0], position[1]+1))
        #left
        if position[1]-1 >= 0 and tgameArray[position[0]][position[1]-1] ==  theColor and (position[0], position[1]-1) not in friends:
            friends.append((position[0], position[1]-1))
        #up
        if position[0]-1 >= 0 and tgameArray[position[0]-1][position[1]] ==  theColor and (position[0]-1, position[1]) not in friends:
            friends.append((position[0]-1, position[1]))
        #down
        if position[0]+1 < mode and tgameArray[position[0]+1][position[1]] ==  theColor and (position[0]+1, position[1]) not in friends:
            friends.append((position[0]+1, position[1]))


def greedy(mode, nconnected, tgameArray):   # basic greedy algorithm, the g(n)
    newconnected = nconnected[:]
    tempgameArray = deepcopy(tgameArray)
    neighborColors = adjacentColors(mode, newconnected, tempgameArray)

    benefits = [[0 for x in range(2)] for y in range(len(neighborColors))]
    for i in range (0, len(neighborColors)):
        benefits[i] = getBenefit(mode, neighborColors[i], newconnected, tempgameArray)

    maxColor = -9999
    maxColorVal = None

    maxLocation = 0, 0

    for p in benefits:
        if p[1] > maxColor:
            maxColor = p[1]
            maxColorVal = p[0][0]
            maxLocation = p[0][1]

    return maxColor, maxColorVal, maxLocation


def gndef1_2(mode, nconnected, tgameArray): # second step if depth3 is used. not recommended :-P
    neighbors = adjacentColors(mode, connected, gameArray)
    benefits = []
    maxVal = -9999
    maxColor = None
    ends = False
    maxLocation = 0, 0

    for i in neighbors:
        newconnected = nconnected[:]
        tgameArray = deepcopy(tgameArray)

        newconnected[0] = i[0]
        tgameArray[0][0] = i[0]

        size = len(newconnected) - 1
        while len(newconnected) > size:
            size = len(newconnected)
            checkConnected(mode, newconnected, tgameArray)

        for j in range(1, len(newconnected)):
            tgameArray[newconnected[j][0]][newconnected[j][1]] = i[0]

        if len(newconnected) == (mode**2 + 1):
            ends = True
            benefits.append(i)
            break

        nextStep = greedy(mode, newconnected, tgameArray)

        benefits.append([i, nextStep])

    for i in range(len(benefits)):
        if benefits[i][1][0] > maxVal:
            maxVal = benefits[i][1][0]
            maxColor = benefits[i][0][0]
            maxLocation = benefits[i][0][1]

    return maxVal, maxColor, maxLocation, ends


def gndef1(mode): # step 1 of depth search
    neighbors = adjacentColors(mode, connected, gameArray)
    benefits = []
    ends = False
    maxVal = -9999
    maxColor = None
    maxLocation = 0, 0

    for i in neighbors:
        newconnected = connected[:]
        tgameArray = deepcopy(gameArray)

        newconnected[0] = i[0]
        tgameArray[0][0] = i[0]

        size = len(newconnected)-1
        while len(newconnected) > size:
            size = len(newconnected)
            checkConnected(mode, newconnected, tgameArray)

        for j in range(1, len(newconnected)):
            tgameArray[newconnected[j][0]][newconnected[j][1]] = i[0]

        if len(newconnected) == (mode**2 + 1):
            ends = True
            benefits.append(i)
            break

        nextStep = greedy(mode, newconnected, tgameArray)   # used if depth2 approach followed
        # nextStep = gndef1_2(mode, newconnected, tgameArray)   #used if depth3 approach followed. not recommended :-P

        if nextStep[3]:
            ends = True
            benefits.append(i)
            break
        benefits.append([i, nextStep])

    if ends:
        maxColor = benefits[len(benefits)-1][0]
        maxLocation = benefits[len(benefits)-1][1]

    else:
        for i in range(len(benefits)):
            if benefits[i][1][0] > maxVal:
                maxVal = benefits[i][1][0]
                maxColor = benefits[i][0][0]
                maxLocation = benefits[i][0][1]

    return maxColor, maxLocation


#########################################################################################################
####################################ADMISSIBLE HEURISTIC#################################################
#########################################################################################################


def getBenefit2(m, color):
    newconnect = connected[:]

    from copy import deepcopy
    tempGameArray = deepcopy(gameArray)

    if color[1][0] < m and color[1][0] >= 0 and color[1][1] < m and color[1][1] >= 0 and (color[1][0], color[1][1]) not in newconnect and tempGameArray[color[1][0]][color[1][1]] != newconnect[0]:
        newconnect[0] = tempGameArray[color[1][0]][color[1][1]]

        tempGameArray[0][0] = tempGameArray[color[1][0]][color[1][1]]
        for s in range (2, len(newconnect)):
            tempGameArray[newconnect[s][0]][newconnect[s][1]] = tempGameArray[0][0]

        size = len(newconnect)-1

        while len(newconnect)>size:
            size = len(newconnect)
            checkConnected(m, newconnect, tempGameArray)

        rem = []

        for i in range(m):
            for j in range(m):
                for k in range(len(colors)):
                    if colors[k] != tempGameArray[0][0] and colors[k] == tempGameArray[i][j] and colors[k] not in rem:
                        rem.append(colors[k])

        value = len(rem)

        return [color, (len(newconnect)+((6-value)*1000))]


def gndef(mode):
    neighborColors = adjacentColors(mode, connected, gameArray)

    benefits = [[0 for x in range(2)] for y in range(len(neighborColors))]
    for i in range (0, len(neighborColors)):
        benefits[i] = getBenefit2(mode, neighborColors[i])

    maxColor = -9999
    maxColorVal = None

    maxLocation = 0, 0

    for p in benefits:
        if p[1] > maxColor:
            maxColor = p[1]
            maxColorVal = p[0][0]
            maxLocation = p[0][1]

    return maxColorVal, maxLocation


#########################################################################################################
##################################ADMISSIBLE HEURISTIC ENDS##############################################
#########################################################################################################


def gameLoop(mode):
    gameExit = False

    while not gameExit:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print(gameArray)
                print(connected)
                print(len(connected))
                gameExit = True

            if event.type == pygame.MOUSEBUTTONDOWN:
                cur = pygame.mouse.get_pos()
                clickPosX = cur[1]
                X = int(clickPosX / 30)
                clickPosY = cur[0]
                Y = int(clickPosY / 30)

                addConnected(mode, X, Y)

        gameDisplay.fill(white)
        gameDraw(mode)
        pygame.display.update()

        rect = pygame.Surface((mode*30, mode*30))
        rect.blit(gameDisplay, (0,0), ((0, 0), (mode*30, mode*30)))

        qq = moves

        name = "screenshot"+str(qq)+".png"

        pygame.image.save(rect, name)

        connected[0] = gameArray[0][0]
        connected[1] = (0,0)

        size = len(connected)-1

        while len(connected)>size:
            size = len(connected)
            checkConnected(mode, connected, gameArray)

        # var = gndef1(mode) # for depth2
        var = gndef(mode) # for remaining color

        if len(connected) == mode * mode + 1:
            break
        addConnected(mode, var[1][0], var[1][1])

    print(moves)
    pygame.quit()

    quit()


game_intro()

